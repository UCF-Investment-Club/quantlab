(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__06.-pfn._.css","static/chunks/node_modules_next_0ur6.u-._.js","static/chunks/components_auth_logout-button_tsx_0fwp~ov._.js"],
    source: "dynamic"
});
