(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/invite/accept/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InviteAcceptPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function InviteAcceptPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const token = searchParams.get("token") ?? "";
    const [verifyState, setVerifyState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    const [role, setRole] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [emailMasked, setEmailMasked] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [fullName, setFullName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [success, setSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [invitedEmail, setInvitedEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const canSubmit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "InviteAcceptPage.useMemo[canSubmit]": ()=>verifyState === "active" && fullName.trim().length > 0 && password.length >= 8
    }["InviteAcceptPage.useMemo[canSubmit]"], [
        verifyState,
        fullName,
        password
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InviteAcceptPage.useEffect": ()=>{
            async function verifyInvite() {
                if (!token) {
                    setVerifyState("missing");
                    return;
                }
                setVerifyState("loading");
                setError(null);
                const response = await fetch(`/api/v1/members/invite/verify?token=${encodeURIComponent(token)}`);
                const payload = await response.json().catch({
                    "InviteAcceptPage.useEffect.verifyInvite": ()=>null
                }["InviteAcceptPage.useEffect.verifyInvite"]);
                if (!response.ok) {
                    setVerifyState("error");
                    setError(payload?.error?.message ?? "Unable to verify invite");
                    return;
                }
                const state = payload?.data?.state ?? "missing";
                setVerifyState(state);
                setRole(payload?.data?.invite?.role ?? null);
                setEmailMasked(payload?.data?.invite?.emailMasked ?? null);
            }
            void verifyInvite();
        }
    }["InviteAcceptPage.useEffect"], [
        token
    ]);
    async function onSubmit(event) {
        event.preventDefault();
        if (!canSubmit) {
            return;
        }
        setSubmitting(true);
        setError(null);
        setSuccess(null);
        try {
            const response = await fetch("/api/v1/members/invite/accept", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    token,
                    fullName,
                    password
                })
            });
            const payload = await response.json().catch(()=>null);
            if (!response.ok) {
                const message = payload?.error?.message ?? "Unable to accept invite";
                if (/already been used|already used/i.test(message)) {
                    setError("This invite was already used. Request a new invite from an admin.");
                    return;
                }
                if (/expired/i.test(message)) {
                    setError("This invite has expired. Request a new invite from an admin.");
                    return;
                }
                if (/invalid/i.test(message)) {
                    setError("This invite link is invalid. Check the URL or request a new invite.");
                    return;
                }
                setError(message);
                return;
            }
            const acceptedEmail = payload?.data?.email ?? null;
            setInvitedEmail(acceptedEmail);
            setSuccess("Account created. Redirecting to sign in...");
            setTimeout(()=>{
                const next = acceptedEmail ? `/login?email=${encodeURIComponent(acceptedEmail)}` : "/login";
                router.push(next);
            }, 900);
        } finally{
            setSubmitting(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "flex min-h-screen items-center justify-center bg-[var(--ql-bg)] px-6 py-12",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "w-full max-w-md rounded-2xl border border-[var(--ql-border)] bg-[var(--ql-surface)] p-8 shadow-[0_18px_40px_rgba(0,0,0,0.4)]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-2xl font-semibold text-[var(--ql-text)]",
                    children: "Accept Invite"
                }, void 0, false, {
                    fileName: "[project]/app/invite/accept/page.tsx",
                    lineNumber: 143,
                    columnNumber: 9
                }, this),
                verifyState === "loading" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-3 text-sm text-[var(--ql-text-muted)]",
                    children: "Validating invite..."
                }, void 0, false, {
                    fileName: "[project]/app/invite/accept/page.tsx",
                    lineNumber: 148,
                    columnNumber: 11
                }, this) : null,
                verifyState === "missing" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-3 text-sm text-[var(--ql-danger)]",
                    children: "Invite token is missing."
                }, void 0, false, {
                    fileName: "[project]/app/invite/accept/page.tsx",
                    lineNumber: 153,
                    columnNumber: 11
                }, this) : null,
                verifyState === "expired" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-3 text-sm text-[var(--ql-danger)]",
                    children: "Invite has expired."
                }, void 0, false, {
                    fileName: "[project]/app/invite/accept/page.tsx",
                    lineNumber: 158,
                    columnNumber: 11
                }, this) : null,
                verifyState === "accepted" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-3 text-sm text-[var(--ql-danger)]",
                    children: "Invite has already been used."
                }, void 0, false, {
                    fileName: "[project]/app/invite/accept/page.tsx",
                    lineNumber: 163,
                    columnNumber: 11
                }, this) : null,
                verifyState === "error" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-3 text-sm text-[var(--ql-danger)]",
                    children: error ?? "Invalid invite."
                }, void 0, false, {
                    fileName: "[project]/app/invite/accept/page.tsx",
                    lineNumber: 168,
                    columnNumber: 11
                }, this) : null,
                verifyState === "active" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-3 text-sm text-[var(--ql-text-muted)]",
                            children: [
                                "Invited account:",
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-medium text-[var(--ql-text)]",
                                    children: emailMasked ?? "-"
                                }, void 0, false, {
                                    fileName: "[project]/app/invite/accept/page.tsx",
                                    lineNumber: 177,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/invite/accept/page.tsx",
                            lineNumber: 175,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-1 text-sm text-[var(--ql-text-muted)]",
                            children: [
                                "Assigned role:",
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-medium text-[var(--ql-text)]",
                                    children: role ?? "MEMBER"
                                }, void 0, false, {
                                    fileName: "[project]/app/invite/accept/page.tsx",
                                    lineNumber: 183,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/invite/accept/page.tsx",
                            lineNumber: 181,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            className: "mt-5 space-y-4",
                            onSubmit: onSubmit,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mb-1 block text-sm font-medium text-[var(--ql-text-muted)]",
                                            children: "Full name"
                                        }, void 0, false, {
                                            fileName: "[project]/app/invite/accept/page.tsx",
                                            lineNumber: 190,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            required: true,
                                            value: fullName,
                                            onChange: (event)=>setFullName(event.target.value),
                                            className: "w-full rounded-lg border border-[var(--ql-border)] bg-[var(--ql-surface-soft)] px-3 py-2 text-sm text-[var(--ql-text)] outline-none placeholder:text-[var(--ql-text-subtle)] focus:border-[var(--ql-gold)] focus:ring-2 focus:ring-[color:var(--ql-gold-glow)]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/invite/accept/page.tsx",
                                            lineNumber: 193,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/invite/accept/page.tsx",
                                    lineNumber: 189,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "mb-1 block text-sm font-medium text-[var(--ql-text-muted)]",
                                            children: "Password"
                                        }, void 0, false, {
                                            fileName: "[project]/app/invite/accept/page.tsx",
                                            lineNumber: 202,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            required: true,
                                            type: "password",
                                            minLength: 8,
                                            value: password,
                                            onChange: (event)=>setPassword(event.target.value),
                                            className: "w-full rounded-lg border border-[var(--ql-border)] bg-[var(--ql-surface-soft)] px-3 py-2 text-sm text-[var(--ql-text)] outline-none placeholder:text-[var(--ql-text-subtle)] focus:border-[var(--ql-gold)] focus:ring-2 focus:ring-[color:var(--ql-gold-glow)]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/invite/accept/page.tsx",
                                            lineNumber: 205,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/invite/accept/page.tsx",
                                    lineNumber: 201,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "submit",
                                    disabled: !canSubmit || submitting,
                                    className: "w-full rounded-lg bg-[var(--ql-gold)] px-4 py-2 text-sm font-semibold text-black transition-colors hover:bg-[var(--ql-gold-strong)] disabled:opacity-60",
                                    children: submitting ? "Creating account..." : "Create account"
                                }, void 0, false, {
                                    fileName: "[project]/app/invite/accept/page.tsx",
                                    lineNumber: 215,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/invite/accept/page.tsx",
                            lineNumber: 188,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true) : null,
                error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-4 text-sm text-[var(--ql-danger)]",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/app/invite/accept/page.tsx",
                    lineNumber: 227,
                    columnNumber: 11
                }, this) : null,
                success ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-4 text-sm text-[var(--ql-success)]",
                    children: [
                        success,
                        invitedEmail ? ` (${invitedEmail})` : ""
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/invite/accept/page.tsx",
                    lineNumber: 230,
                    columnNumber: 11
                }, this) : null
            ]
        }, void 0, true, {
            fileName: "[project]/app/invite/accept/page.tsx",
            lineNumber: 142,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/invite/accept/page.tsx",
        lineNumber: 141,
        columnNumber: 5
    }, this);
}
_s(InviteAcceptPage, "VHAopeWpJPe1D5Iq87ds8Vrz7hE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = InviteAcceptPage;
var _c;
__turbopack_context__.k.register(_c, "InviteAcceptPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_invite_accept_page_tsx_06pp6ji._.js.map